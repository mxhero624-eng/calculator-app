import { useMemo, useState } from 'react';
import { NumberField, Notice, Segmented, Slider, Stat, cx } from '../components/ui';
import { fmt, num } from '../lib/format';

type System = 'metric' | 'imperial';

const CATEGORIES = [
  { name: 'Underweight', max: 18.5, text: 'text-sky-500', bg: 'bg-sky-400', soft: 'bg-sky-50' },
  { name: 'Normal', max: 25, text: 'text-emerald-500', bg: 'bg-emerald-400', soft: 'bg-emerald-50' },
  { name: 'Overweight', max: 30, text: 'text-orange-500', bg: 'bg-orange-400', soft: 'bg-orange-50' },
  { name: 'Obese', max: Infinity, text: 'text-rose-500', bg: 'bg-rose-400', soft: 'bg-rose-50' },
];

const SCALE_MIN = 15;
const SCALE_MAX = 40;

export default function BmiCalculator() {
  const [system, setSystem] = useState<System>('metric');
  const [weight, setWeight] = useState('70'); // kg or lb
  const [heightCm, setHeightCm] = useState('175');
  const [feet, setFeet] = useState('5');
  const [inches, setInches] = useState('9');

  const switchSystem = (next: System) => {
    if (next === system) return;
    if (next === 'imperial') {
      const kg = num(weight);
      const totalIn = num(heightCm) / 2.54;
      let ft = Math.floor(totalIn / 12);
      let inch = Math.round(totalIn - ft * 12);
      if (inch === 12) {
        ft += 1;
        inch = 0;
      }
      setWeight(kg ? String(Math.round(kg * 2.20462262 * 10) / 10) : '');
      setFeet(String(ft));
      setInches(String(inch));
    } else {
      const lb = num(weight);
      const cm = (num(feet) * 12 + num(inches)) * 2.54;
      setWeight(lb ? String(Math.round((lb / 2.20462262) * 10) / 10) : '');
      setHeightCm(cm ? String(Math.round(cm)) : '');
    }
    setSystem(next);
  };

  const { kg, m } = useMemo(() => {
    if (system === 'metric') return { kg: num(weight), m: num(heightCm) / 100 };
    return { kg: num(weight) * 0.45359237, m: (num(feet) * 12 + num(inches)) * 0.0254 };
  }, [system, weight, heightCm, feet, inches]);

  const valid = kg > 0 && m > 0;
  const bmi = valid ? kg / (m * m) : 0;
  const cat = CATEGORIES.find((c) => bmi < c.max) ?? CATEGORIES[3];
  const markerPct = Math.min(100, Math.max(0, ((bmi - SCALE_MIN) / (SCALE_MAX - SCALE_MIN)) * 100));

  const healthyMin = 18.5 * m * m;
  const healthyMax = 24.9 * m * m;
  const toDisplayWeight = (k: number) => (system === 'metric' ? `${fmt(k, 1)} kg` : `${fmt(k * 2.20462262, 1)} lb`);

  return (
    <div className="space-y-5">
      <Segmented
        options={[
          { value: 'metric', label: 'Metric' },
          { value: 'imperial', label: 'Imperial' },
        ]}
        value={system}
        onChange={switchSystem}
      />

      <div>
        <NumberField
          label={`Weight (${system === 'metric' ? 'kg' : 'lb'})`}
          value={weight}
          onChange={setWeight}
          suffix={system === 'metric' ? 'kg' : 'lb'}
          stepper
          step={system === 'metric' ? 0.5 : 1}
          min={0}
        />
        <Slider
          label="Weight slider"
          value={num(weight)}
          onChange={(v) => setWeight(String(v))}
          min={system === 'metric' ? 20 : 45}
          max={system === 'metric' ? 200 : 440}
          step={system === 'metric' ? 0.5 : 1}
        />
      </div>

      {system === 'metric' ? (
        <div>
          <NumberField label="Height (cm)" value={heightCm} onChange={setHeightCm} suffix="cm" stepper min={0} />
          <Slider label="Height slider" value={num(heightCm)} onChange={(v) => setHeightCm(String(v))} min={100} max={230} />
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-3">
          <NumberField label="Height (ft)" value={feet} onChange={setFeet} suffix="ft" />
          <NumberField label="Height (in)" value={inches} onChange={setInches} suffix="in" />
        </div>
      )}

      {!valid ? (
        <Notice>Enter a weight and height greater than zero to calculate your BMI.</Notice>
      ) : (
        <>
          <div className={cx('rounded-3xl p-5 text-center transition-all duration-300', cat.soft)}>
            <p className="text-xs font-medium uppercase tracking-wide text-gray-500">Your BMI</p>
            <p className={cx('mt-1 text-5xl font-bold tracking-tight', cat.text)}>{fmt(bmi, 1)}</p>
            <span className={cx('mt-2 inline-block rounded-full px-3 py-1 text-xs font-bold text-white', cat.bg)}>
              {cat.name}
            </span>
          </div>

          {/* Scale */}
          <div>
            <div className="relative pt-5">
              <div
                className="absolute top-0 -translate-x-1/2 transition-all duration-500"
                style={{ left: `${markerPct}%` }}
              >
                <div className="h-0 w-0 border-x-[7px] border-t-[9px] border-x-transparent border-t-gray-800" />
              </div>
              <div className="flex h-3 overflow-hidden rounded-full">
                <div className="bg-sky-400" style={{ width: `${((18.5 - SCALE_MIN) / 25) * 100}%` }} />
                <div className="bg-emerald-400" style={{ width: `${(6.5 / 25) * 100}%` }} />
                <div className="bg-orange-400" style={{ width: `${(5 / 25) * 100}%` }} />
                <div className="flex-1 bg-rose-400" />
              </div>
            </div>
            <div className="relative mt-1.5 h-4 text-[10px] font-medium text-gray-400">
              {[15, 18.5, 25, 30, 40].map((v) => (
                <span
                  key={v}
                  className="absolute -translate-x-1/2 first:translate-x-0 last:-translate-x-full"
                  style={{ left: `${((v - SCALE_MIN) / 25) * 100}%` }}
                >
                  {v}
                </span>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <Stat label="Healthy weight" value={`${toDisplayWeight(healthyMin)} – ${toDisplayWeight(healthyMax)}`} />
            <Stat
              label={bmi < 18.5 ? 'To gain' : bmi >= 25 ? 'To lose' : 'Status'}
              value={
                bmi < 18.5
                  ? toDisplayWeight(healthyMin - kg)
                  : bmi >= 25
                    ? toDisplayWeight(kg - healthyMax)
                    : 'In healthy range'
              }
              accent={cat.text}
            />
          </div>
        </>
      )}
    </div>
  );
}
