import { useMemo, useState } from 'react';
import { CalendarCheck } from 'lucide-react';
import { DateField, NumberField, Notice, ResultHero, Segmented, Stat } from '../components/ui';
import { addDays, compare, diffYMD, formatLong, parseISO, todayISO, totalDaysBetween, toISO } from '../lib/dates';
import { int, num, plural } from '../lib/format';

type Mode = 'diff' | 'add';

export default function DateCalculator() {
  const today = todayISO();
  const [mode, setMode] = useState<Mode>('diff');
  const [start, setStart] = useState(today);
  const [end, setEnd] = useState(() => {
    const t = parseISO(today)!;
    return toISO({ y: t.y + 1, m: 1, d: 1 });
  });
  const [base, setBase] = useState(today);
  const [days, setDays] = useState('100');
  const [direction, setDirection] = useState<'add' | 'sub'>('add');

  const diff = useMemo(() => {
    const a = parseISO(start);
    const b = parseISO(end);
    if (!a || !b) return null;
    const reversed = compare(a, b) > 0;
    const [from, to] = reversed ? [b, a] : [a, b];
    const total = totalDaysBetween(from, to);
    return { ...diffYMD(from, to), total, reversed, weeks: Math.floor(total / 7), remDays: total % 7 };
  }, [start, end]);

  const added = useMemo(() => {
    const b = parseISO(base);
    if (!b) return null;
    const n = Math.trunc(num(days));
    const result = addDays(b, direction === 'add' ? n : -n);
    return { result, n };
  }, [base, days, direction]);

  return (
    <div className="space-y-5">
      <Segmented
        options={[
          { value: 'diff', label: 'Date Difference' },
          { value: 'add', label: 'Add / Subtract' },
        ]}
        value={mode}
        onChange={setMode}
      />

      {mode === 'diff' ? (
        <>
          <div className="grid grid-cols-1 gap-3 min-[400px]:grid-cols-2">
            <DateField label="Start date" value={start} onChange={setStart} />
            <DateField label="End date" value={end} onChange={setEnd} />
          </div>
          <div className="flex gap-2">
            <button
              type="button"
              onClick={() => setStart(today)}
              className="rounded-xl bg-violet-50 px-3 py-1.5 text-xs font-semibold text-violet-600 transition-all hover:bg-violet-100 active:scale-95"
            >
              Start = Today
            </button>
            <button
              type="button"
              onClick={() => setEnd(today)}
              className="rounded-xl bg-violet-50 px-3 py-1.5 text-xs font-semibold text-violet-600 transition-all hover:bg-violet-100 active:scale-95"
            >
              End = Today
            </button>
          </div>
          {!diff ? (
            <Notice>Pick both a start and end date.</Notice>
          ) : (
            <>
              <ResultHero
                label={diff.reversed ? 'Difference (end is before start)' : 'Time between dates'}
                value={
                  <span className="text-2xl sm:text-3xl">
                    {plural(diff.years, 'year')}, {plural(diff.months, 'month')}, {plural(diff.days, 'day')}
                  </span>
                }
              />
              <div className="grid grid-cols-2 gap-3">
                <Stat label="Total days" value={int(diff.total)} accent="text-violet-600" />
                <Stat label="Weeks" value={`${int(diff.weeks)}w ${diff.remDays}d`} />
                <Stat label="Total hours" value={int(diff.total * 24)} />
                <Stat label="Total months" value={int(diff.years * 12 + diff.months)} />
              </div>
            </>
          )}
        </>
      ) : (
        <>
          <DateField label="Start date" value={base} onChange={setBase} />
          <NumberField label="Number of days" value={days} onChange={setDays} suffix="days" stepper min={0} />
          <Segmented
            options={[
              { value: 'add', label: '+ Add' },
              { value: 'sub', label: '− Subtract' },
            ]}
            value={direction}
            onChange={setDirection}
          />
          {!added ? (
            <Notice>Pick a valid start date.</Notice>
          ) : (
            <ResultHero
              label={`${direction === 'add' ? 'Adding' : 'Subtracting'} ${plural(added.n, 'day')}`}
              value={<span className="text-2xl sm:text-3xl">{formatLong(added.result)}</span>}
              sub={
                <span className="inline-flex items-center gap-1.5">
                  <CalendarCheck size={14} /> {toISO(added.result)}
                </span>
              }
            />
          )}
        </>
      )}
    </div>
  );
}
