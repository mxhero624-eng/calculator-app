import { useMemo, useState } from 'react';
import { NumberField, ResultHero, Segmented, SelectField, SwapButton } from '../components/ui';
import { num, smart } from '../lib/format';

type Category = 'length' | 'weight' | 'volume' | 'area';

interface Unit {
  id: string;
  label: string;
  factor: number; // to base unit
}

// Base units: metre, kilogram, litre, square metre (exact international definitions)
const UNITS: Record<Category, Unit[]> = {
  length: [
    { id: 'km', label: 'Kilometer (km)', factor: 1000 },
    { id: 'm', label: 'Meter (m)', factor: 1 },
    { id: 'cm', label: 'Centimeter (cm)', factor: 0.01 },
    { id: 'mm', label: 'Millimeter (mm)', factor: 0.001 },
    { id: 'mi', label: 'Mile (mi)', factor: 1609.344 },
    { id: 'yd', label: 'Yard (yd)', factor: 0.9144 },
    { id: 'ft', label: 'Foot (ft)', factor: 0.3048 },
    { id: 'in', label: 'Inch (in)', factor: 0.0254 },
  ],
  weight: [
    { id: 'kg', label: 'Kilogram (kg)', factor: 1 },
    { id: 'g', label: 'Gram (g)', factor: 0.001 },
    { id: 'mg', label: 'Milligram (mg)', factor: 0.000001 },
    { id: 'lb', label: 'Pound (lb)', factor: 0.45359237 },
    { id: 'oz', label: 'Ounce (oz)', factor: 0.028349523125 },
    { id: 'ton', label: 'Metric ton (t)', factor: 1000 },
  ],
  volume: [
    { id: 'L', label: 'Liter (L)', factor: 1 },
    { id: 'mL', label: 'Milliliter (mL)', factor: 0.001 },
    { id: 'gal', label: 'US Gallon (gal)', factor: 3.785411784 },
    { id: 'qt', label: 'US Quart (qt)', factor: 0.946352946 },
    { id: 'pt', label: 'US Pint (pt)', factor: 0.473176473 },
    { id: 'cup', label: 'US Cup (cup)', factor: 0.2365882365 },
    { id: 'fl oz', label: 'US Fluid ounce (fl oz)', factor: 0.0295735295625 },
  ],
  area: [
    { id: 'km²', label: 'Square kilometer (km²)', factor: 1_000_000 },
    { id: 'm²', label: 'Square meter (m²)', factor: 1 },
    { id: 'cm²', label: 'Square centimeter (cm²)', factor: 0.0001 },
    { id: 'mi²', label: 'Square mile (mi²)', factor: 2_589_988.110336 },
    { id: 'yd²', label: 'Square yard (yd²)', factor: 0.83612736 },
    { id: 'ft²', label: 'Square foot (ft²)', factor: 0.09290304 },
    { id: 'in²', label: 'Square inch (in²)', factor: 0.00064516 },
    { id: 'acre', label: 'Acre', factor: 4046.8564224 },
    { id: 'hectare', label: 'Hectare (ha)', factor: 10_000 },
  ],
};

const DEFAULTS: Record<Category, [string, string]> = {
  length: ['km', 'mi'],
  weight: ['kg', 'lb'],
  volume: ['L', 'gal'],
  area: ['m²', 'ft²'],
};

export default function UnitConverter() {
  const [category, setCategory] = useState<Category>('length');
  const [value, setValue] = useState('1');
  const [from, setFrom] = useState('km');
  const [to, setTo] = useState('mi');

  const changeCategory = (c: Category) => {
    setCategory(c);
    setFrom(DEFAULTS[c][0]);
    setTo(DEFAULTS[c][1]);
  };

  const units = UNITS[category];
  const options = units.map((u) => ({ value: u.id, label: u.label }));
  const fromU = units.find((u) => u.id === from) ?? units[0];
  const toU = units.find((u) => u.id === to) ?? units[1];

  const v = num(value);
  const ratio = fromU.factor / toU.factor;
  const result = v * ratio;

  const table = useMemo(
    () => units.filter((u) => u.id !== fromU.id).map((u) => ({ u, val: v * (fromU.factor / u.factor) })),
    [units, fromU, v],
  );

  return (
    <div className="space-y-5">
      <Segmented
        size="sm"
        options={[
          { value: 'length', label: 'Length' },
          { value: 'weight', label: 'Weight' },
          { value: 'volume', label: 'Volume' },
          { value: 'area', label: 'Area' },
        ]}
        value={category}
        onChange={changeCategory}
      />

      <NumberField label="Value" value={value} onChange={setValue} suffix={fromU.id} allowNegative={category === 'length'} />

      <div className="flex items-end gap-2">
        <div className="min-w-0 flex-1">
          <SelectField label="From" value={fromU.id} onChange={setFrom} options={options} />
        </div>
        <SwapButton
          label="Swap units"
          onClick={() => {
            setFrom(toU.id);
            setTo(fromU.id);
          }}
        />
        <div className="min-w-0 flex-1">
          <SelectField label="To" value={toU.id} onChange={setTo} options={options} />
        </div>
      </div>

      <ResultHero
        label={`${smart(v)} ${fromU.id} equals`}
        value={
          <span>
            {smart(result)} <span className="text-xl font-medium text-violet-100">{toU.id}</span>
          </span>
        }
        sub={`1 ${fromU.id} = ${smart(ratio, 6)} ${toU.id} · 1 ${toU.id} = ${smart(1 / ratio, 6)} ${fromU.id}`}
      />

      <div>
        <p className="mb-2 text-xs font-medium uppercase tracking-wide text-gray-500">All conversions</p>
        <div className="divide-y divide-gray-100 overflow-hidden rounded-2xl bg-gray-50">
          {table.map(({ u, val }) => (
            <button
              key={u.id}
              type="button"
              onClick={() => setTo(u.id)}
              className={`flex w-full items-center justify-between px-4 py-2.5 text-left text-sm transition-all duration-150 hover:bg-violet-50 ${
                u.id === toU.id ? 'bg-violet-50' : ''
              }`}
            >
              <span className={u.id === toU.id ? 'font-semibold text-violet-600' : 'text-gray-500'}>{u.label}</span>
              <span className="truncate pl-3 font-bold text-gray-800">{smart(val)}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
