import { useMemo, useState } from 'react';
import { NumberField, ResultHero, Slider, Stat } from '../components/ui';
import { money, num } from '../lib/format';

/** FV = P(1+r/n)^(nt) + PMT × [((1+r/n)^(nt) − 1) / (r/n)], n = 12 */
export function futureValue(P: number, PMT: number, annualRatePct: number, years: number): number {
  const n = 12;
  const r = annualRatePct / 100;
  const periods = n * years;
  if (r === 0) return P + PMT * periods;
  const i = r / n;
  const growth = Math.pow(1 + i, periods);
  return P * growth + PMT * ((growth - 1) / i);
}

export default function InvestmentCalculator() {
  const [initial, setInitial] = useState('2000');
  const [monthly, setMonthly] = useState('1500');
  const [rate, setRate] = useState('7.5');
  const [years, setYears] = useState('3');

  const data = useMemo(() => {
    const P = Math.max(0, num(initial));
    const PMT = Math.max(0, num(monthly));
    const r = Math.max(0, num(rate));
    const t = Math.max(0, Math.min(100, num(years)));
    const fv = futureValue(P, PMT, r, t);
    const contributions = P + PMT * 12 * t;
    const interest = fv - contributions;
    // Yearly balances for the mini chart (max 30 bars)
    const totalYears = Math.ceil(t);
    const stepYears = Math.max(1, Math.ceil(totalYears / 30));
    const bars: { year: number; total: number; principal: number }[] = [];
    for (let y = stepYears; y <= totalYears; y += stepYears) {
      const yy = Math.min(y, t);
      bars.push({ year: yy, total: futureValue(P, PMT, r, yy), principal: P + PMT * 12 * yy });
    }
    if (bars.length && bars[bars.length - 1].year !== t && t > 0) {
      bars.push({ year: t, total: fv, principal: contributions });
    }
    return { P, PMT, r, t, fv, contributions, interest, bars };
  }, [initial, monthly, rate, years]);

  const principalPct = data.fv > 0 ? (data.contributions / data.fv) * 100 : 100;
  const maxBar = Math.max(1, ...data.bars.map((b) => b.total));

  return (
    <div className="space-y-5">
      <div className="grid grid-cols-2 gap-3">
        <NumberField label="Initial investment" value={initial} onChange={setInitial} prefix="$" />
        <NumberField label="Monthly contribution" value={monthly} onChange={setMonthly} prefix="$" />
      </div>

      <div>
        <NumberField label="Annual interest rate" value={rate} onChange={setRate} suffix="%" />
        <Slider label="Interest rate" value={num(rate)} onChange={(v) => setRate(String(v))} min={0} max={20} step={0.1} />
      </div>

      <div>
        <NumberField label="Investment period" value={years} onChange={setYears} suffix="years" stepper min={0} max={100} />
        <Slider label="Years" value={num(years)} onChange={(v) => setYears(String(v))} min={1} max={50} />
      </div>

      <ResultHero label="Future value" value={money(data.fv)}>
        <p className="text-xs leading-relaxed text-violet-100">
          Investing {money(data.P)} with {money(data.PMT)} monthly at {data.r}% for {data.t}{' '}
          {data.t === 1 ? 'year' : 'years'} (compounded monthly).
        </p>
      </ResultHero>

      <div className="grid grid-cols-2 gap-3">
        <Stat label="Total contributions" value={money(data.contributions)} />
        <Stat label="Interest earned" value={money(data.interest)} accent="text-emerald-500" />
      </div>

      <div>
        <div className="mb-2 flex justify-between text-xs font-medium">
          <span className="flex items-center gap-1.5 text-gray-500">
            <span className="h-2.5 w-2.5 rounded-full bg-violet-300" /> Principal {principalPct.toFixed(1)}%
          </span>
          <span className="flex items-center gap-1.5 text-gray-500">
            <span className="h-2.5 w-2.5 rounded-full bg-violet-600" /> Interest {(100 - principalPct).toFixed(1)}%
          </span>
        </div>
        <div className="flex h-3 overflow-hidden rounded-full bg-violet-100">
          <div className="bg-violet-300 transition-all duration-500" style={{ width: `${principalPct}%` }} />
          <div className="flex-1 bg-violet-600" />
        </div>
      </div>

      {data.bars.length > 1 && (
        <div className="rounded-2xl bg-gray-50 p-4">
          <p className="mb-3 text-xs font-medium uppercase tracking-wide text-gray-500">Growth by year</p>
          <div className="flex h-28 items-end gap-1">
            {data.bars.map((b) => (
              <div
                key={b.year}
                title={`Year ${b.year}: ${money(b.total)}`}
                className="group relative flex flex-1 flex-col justify-end overflow-hidden rounded-t-md"
                style={{ height: `${(b.total / maxBar) * 100}%` }}
              >
                <div className="bg-violet-600 transition-all group-hover:bg-purple-700" style={{ height: `${((b.total - b.principal) / b.total) * 100}%` }} />
                <div className="flex-1 bg-violet-300 transition-all group-hover:bg-violet-400" />
              </div>
            ))}
          </div>
          <div className="mt-1 flex justify-between text-[10px] text-gray-400">
            <span>Year {data.bars[0].year}</span>
            <span>Year {data.bars[data.bars.length - 1].year}</span>
          </div>
        </div>
      )}
    </div>
  );
}
