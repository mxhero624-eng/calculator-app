import { useMemo, useState } from 'react';
import { NumberField, ResultHero, SelectField, SwapButton } from '../components/ui';
import { num } from '../lib/format';

// Realistic 2024 reference rates (USD base)
export const RATES: Record<string, number> = {
  USD: 1,
  EUR: 0.92,
  GBP: 0.79,
  JPY: 149.5,
  INR: 83.1,
  CAD: 1.36,
  AUD: 1.53,
  CHF: 0.88,
  CNY: 7.24,
  BRL: 4.97,
};

const NAMES: Record<string, string> = {
  USD: 'US Dollar',
  EUR: 'Euro',
  GBP: 'British Pound',
  JPY: 'Japanese Yen',
  INR: 'Indian Rupee',
  CAD: 'Canadian Dollar',
  AUD: 'Australian Dollar',
  CHF: 'Swiss Franc',
  CNY: 'Chinese Yuan',
  BRL: 'Brazilian Real',
};

const FLAGS: Record<string, string> = {
  USD: '🇺🇸', EUR: '🇪🇺', GBP: '🇬🇧', JPY: '🇯🇵', INR: '🇮🇳',
  CAD: '🇨🇦', AUD: '🇦🇺', CHF: '🇨🇭', CNY: '🇨🇳', BRL: '🇧🇷',
};

export function formatCurrency(amount: number, code: string) {
  if (!Number.isFinite(amount)) return '—';
  return new Intl.NumberFormat('en-US', { style: 'currency', currency: code }).format(amount);
}

function rateStr(r: number) {
  if (r >= 100) return r.toLocaleString('en-US', { maximumFractionDigits: 2 });
  if (r >= 1) return r.toLocaleString('en-US', { maximumFractionDigits: 4 });
  return r.toLocaleString('en-US', { maximumSignificantDigits: 4 });
}

export default function CurrencyConverter() {
  const [amount, setAmount] = useState('100');
  const [from, setFrom] = useState('USD');
  const [to, setTo] = useState('EUR');

  const options = useMemo(
    () => Object.keys(RATES).map((c) => ({ value: c, label: `${FLAGS[c]} ${c} — ${NAMES[c]}` })),
    [],
  );

  const value = num(amount);
  const rate = RATES[to] / RATES[from];
  const result = value * rate;

  const others = Object.keys(RATES).filter((c) => c !== from && c !== to).slice(0, 6);

  return (
    <div className="space-y-5">
      <NumberField label="Amount" value={amount} onChange={setAmount} prefix={FLAGS[from]} suffix={from} />

      <div className="flex items-end gap-2">
        <div className="min-w-0 flex-1">
          <SelectField label="From" value={from} onChange={setFrom} options={options} />
        </div>
        <SwapButton
          label="Swap currencies"
          onClick={() => {
            setFrom(to);
            setTo(from);
          }}
        />
        <div className="min-w-0 flex-1">
          <SelectField label="To" value={to} onChange={setTo} options={options} />
        </div>
      </div>

      <ResultHero
        label={`${formatCurrency(value, from)} equals`}
        value={formatCurrency(result, to)}
        sub={
          <>
            1 {from} = {rateStr(rate)} {to} · 1 {to} = {rateStr(1 / rate)} {from}
          </>
        }
      />

      <div>
        <p className="mb-2 text-xs font-medium uppercase tracking-wide text-gray-500">
          {formatCurrency(value, from)} in other currencies
        </p>
        <div className="grid grid-cols-2 gap-2">
          {others.map((c) => (
            <button
              key={c}
              type="button"
              onClick={() => setTo(c)}
              className="flex items-center justify-between rounded-2xl bg-gray-50 px-3 py-2.5 text-left transition-all duration-200 hover:scale-[1.02] hover:bg-violet-50"
            >
              <span className="text-xs font-semibold text-gray-500">
                {FLAGS[c]} {c}
              </span>
              <span className="truncate pl-2 text-sm font-bold text-gray-800">
                {formatCurrency(value * (RATES[c] / RATES[from]), c)}
              </span>
            </button>
          ))}
        </div>
      </div>
      <p className="text-center text-[11px] text-gray-400">Reference rates (2024), works fully offline.</p>
    </div>
  );
}
