import { useMemo, useState } from 'react';
import { Target } from 'lucide-react';
import { NumberField, Notice, ResultHero, Stat } from '../components/ui';
import { money, num } from '../lib/format';

const MAX_MONTHS = 1200; // 100 years

export default function SavingsCalculator() {
  const [goal, setGoal] = useState('20000');
  const [current, setCurrent] = useState('3500');
  const [deposit, setDeposit] = useState('500');
  const [rate, setRate] = useState('4.5');

  const r = useMemo(() => {
    const G = Math.max(0, num(goal));
    const C = Math.max(0, num(current));
    const D = Math.max(0, num(deposit));
    const rateYr = Math.max(0, num(rate));
    const i = rateYr / 100 / 12;
    const progress = G > 0 ? Math.min(100, (C / G) * 100) : 0;

    if (G <= 0) return { status: 'nogoal' as const, progress };
    if (C >= G) return { status: 'done' as const, progress, G, C };

    let balance = C;
    let months = 0;
    let interest = 0;
    while (balance < G && months < MAX_MONTHS) {
      const earned = balance * i;
      interest += earned;
      balance += earned + D;
      months += 1;
    }
    if (balance < G) return { status: 'unreachable' as const, progress, G, C };
    const deposited = D * months;
    const target = new Date();
    target.setMonth(target.getMonth() + months);
    return {
      status: 'ok' as const,
      progress,
      G,
      C,
      months,
      interest,
      deposited,
      final: balance,
      years: Math.floor(months / 12),
      remMonths: months % 12,
      targetDate: target.toLocaleDateString('en-US', { month: 'long', year: 'numeric' }),
    };
  }, [goal, current, deposit, rate]);

  return (
    <div className="space-y-5">
      <NumberField label="Savings goal" value={goal} onChange={setGoal} prefix="$" />
      <div className="grid grid-cols-2 gap-3">
        <NumberField label="Current savings" value={current} onChange={setCurrent} prefix="$" />
        <NumberField label="Monthly deposit" value={deposit} onChange={setDeposit} prefix="$" />
      </div>
      <NumberField label="Annual interest rate" value={rate} onChange={setRate} suffix="%" />

      <div className="rounded-2xl bg-gray-50 p-4">
        <div className="mb-2 flex items-center justify-between">
          <span className="flex items-center gap-1.5 text-xs font-medium uppercase tracking-wide text-gray-500">
            <Target size={14} className="text-violet-500" /> Current progress
          </span>
          <span className="text-sm font-bold text-violet-600">{r.progress.toFixed(1)}%</span>
        </div>
        <div className="h-3 overflow-hidden rounded-full bg-violet-100">
          <div
            className="h-full rounded-full bg-gradient-to-r from-violet-400 to-purple-600 transition-all duration-500"
            style={{ width: `${r.progress}%` }}
          />
        </div>
        {r.status !== 'nogoal' && (
          <p className="mt-2 text-xs text-gray-400">
            {money(r.C)} of {money(r.G)}
          </p>
        )}
      </div>

      {r.status === 'nogoal' && <Notice>Enter a savings goal greater than zero.</Notice>}
      {r.status === 'done' && <Notice tone="info">🎉 You've already reached your goal!</Notice>}
      {r.status === 'unreachable' && (
        <Notice>With these numbers the goal can't be reached within 100 years. Try increasing your monthly deposit.</Notice>
      )}
      {r.status === 'ok' && (
        <>
          <ResultHero
            label="Time to reach your goal"
            value={`${r.months.toLocaleString('en-US')} ${r.months === 1 ? 'month' : 'months'}`}
            sub={`${r.years} ${r.years === 1 ? 'year' : 'years'}, ${r.remMonths} ${r.remMonths === 1 ? 'month' : 'months'} · around ${r.targetDate}`}
          />
          <div className="grid grid-cols-2 gap-3">
            <Stat label="Interest earned" value={money(r.interest)} accent="text-emerald-500" />
            <Stat label="Total deposited" value={money(r.deposited)} />
            <Stat label="Final balance" value={money(r.final)} accent="text-violet-600" />
            <Stat label="Still needed" value={money(r.G - r.C)} />
          </div>
        </>
      )}
    </div>
  );
}
