import { useState } from 'react';
import { Snowflake, Sun } from 'lucide-react';
import { Label, NumberField, Notice, Segmented, SwapButton } from '../components/ui';
import { num, smart } from '../lib/format';

type Scale = 'C' | 'F' | 'K';

const SYMBOL: Record<Scale, string> = { C: '°C', F: '°F', K: 'K' };
const NAME: Record<Scale, string> = { C: 'Celsius', F: 'Fahrenheit', K: 'Kelvin' };

function toCelsius(v: number, s: Scale) {
  if (s === 'C') return v;
  if (s === 'F') return ((v - 32) * 5) / 9;
  return v - 273.15;
}

function fromCelsius(c: number, s: Scale) {
  if (s === 'C') return c;
  if (s === 'F') return (c * 9) / 5 + 32;
  return c + 273.15;
}

const FORMULAS: Record<string, string> = {
  'C-F': '°F = °C × 9/5 + 32',
  'C-K': 'K = °C + 273.15',
  'F-C': '°C = (°F − 32) × 5/9',
  'F-K': 'K = (°F − 32) × 5/9 + 273.15',
  'K-C': '°C = K − 273.15',
  'K-F': '°F = (K − 273.15) × 9/5 + 32',
};

function feel(c: number) {
  if (c <= 0) return 'Freezing';
  if (c < 10) return 'Cold';
  if (c < 20) return 'Cool';
  if (c < 27) return 'Pleasant';
  if (c < 35) return 'Hot';
  return 'Scorching';
}

/** Map Celsius to a blue→purple→red color. */
function tempColor(c: number) {
  const t = Math.min(1, Math.max(0, (c + 30) / 80)); // -30°C .. 50°C
  const hue = 220 - t * 220; // 220 (blue) -> 0 (red)
  return `hsl(${hue}, 85%, 58%)`;
}

export default function TemperatureConverter() {
  const [value, setValue] = useState('25');
  const [from, setFrom] = useState<Scale>('C');
  const [to, setTo] = useState<Scale>('F');

  const v = num(value);
  const celsius = toCelsius(v, from);
  const belowZero = celsius < -273.15 - 1e-9;
  const result = fromCelsius(celsius, to);
  const color = tempColor(celsius);
  const fillPct = Math.min(100, Math.max(4, ((celsius + 30) / 80) * 100));

  const scaleOptions = (['C', 'F', 'K'] as Scale[]).map((s) => ({ value: s, label: SYMBOL[s] }));

  return (
    <div className="space-y-5">
      <NumberField label="Temperature" value={value} onChange={setValue} suffix={SYMBOL[from]} allowNegative />

      <div className="flex items-end gap-2">
        <div className="flex-1">
          <Label>From</Label>
          <Segmented options={scaleOptions} value={from} onChange={setFrom} size="sm" />
        </div>
        <SwapButton
          label="Swap scales"
          onClick={() => {
            setFrom(to);
            setTo(from);
          }}
        />
        <div className="flex-1">
          <Label>To</Label>
          <Segmented options={scaleOptions} value={to} onChange={setTo} size="sm" />
        </div>
      </div>

      {belowZero ? (
        <Notice>That's below absolute zero (−273.15 °C / −459.67 °F / 0 K) — physically impossible!</Notice>
      ) : (
        <div className="flex gap-4 rounded-3xl bg-gray-50 p-5">
          {/* Thermometer */}
          <div className="flex flex-col items-center">
            <Sun size={14} className="text-rose-400" />
            <div className="relative my-1 h-36 w-4 overflow-hidden rounded-full bg-white shadow-inner">
              <div
                className="absolute bottom-0 w-full rounded-full transition-all duration-500"
                style={{ height: `${fillPct}%`, background: `linear-gradient(to top, #60A5FA, ${color})` }}
              />
            </div>
            <div className="-mt-2 h-7 w-7 rounded-full border-4 border-white shadow" style={{ background: color }} />
            <Snowflake size={14} className="mt-1 text-sky-400" />
          </div>

          <div className="flex min-w-0 flex-1 flex-col justify-center">
            <p className="text-xs font-medium uppercase tracking-wide text-gray-400">
              {smart(v)} {SYMBOL[from]} in {NAME[to]}
            </p>
            <p className="mt-1 break-words text-4xl font-bold tracking-tight transition-colors duration-500 sm:text-5xl" style={{ color }}>
              {smart(Math.abs(result) < 1e-10 ? 0 : result, 8)}
              <span className="text-2xl">{SYMBOL[to]}</span>
            </p>
            <span
              className="mt-2 w-fit rounded-full px-3 py-1 text-xs font-bold text-white transition-colors duration-500"
              style={{ background: color }}
            >
              {feel(celsius)}
            </span>
            <p className="mt-3 rounded-xl bg-white px-3 py-2 font-mono text-xs text-violet-600">
              {from === to ? `${SYMBOL[to]} = ${SYMBOL[from]} (same scale)` : FORMULAS[`${from}-${to}`]}
            </p>
          </div>
        </div>
      )}

      <div className="grid grid-cols-3 gap-2">
        {(['C', 'F', 'K'] as Scale[]).map((s) => (
          <div key={s} className="rounded-2xl bg-violet-50/60 p-3 text-center">
            <p className="text-[11px] font-medium uppercase tracking-wide text-gray-400">{NAME[s]}</p>
            <p className="mt-0.5 truncate text-sm font-bold text-gray-800">
              {belowZero ? '—' : `${smart(fromCelsius(celsius, s), 6)}${SYMBOL[s]}`}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
}
