import { useMemo, useState } from 'react';
import { PartyPopper } from 'lucide-react';
import { DateField, Notice, ResultHero, Stat } from '../components/ui';
import { compare, daysInMonth, diffYMD, formatLong, parseISO, todayISO, totalDaysBetween, weekday, type YMD } from '../lib/dates';
import { int, plural } from '../lib/format';

function birthdayIn(year: number, dob: YMD): YMD {
  // Feb 29 birthdays fall on Feb 28 in non-leap years
  const d = Math.min(dob.d, daysInMonth(year, dob.m));
  return { y: year, m: dob.m, d };
}

export default function AgeCalculator() {
  const today = todayISO();
  const [dob, setDob] = useState('1995-06-15');

  const result = useMemo(() => {
    const birth = parseISO(dob);
    const now = parseISO(today)!;
    if (!birth) return { error: 'Please choose your date of birth.' } as const;
    if (compare(birth, now) > 0) return { error: 'Date of birth cannot be in the future.' } as const;

    const age = diffYMD(birth, now);
    const totalDays = totalDaysBetween(birth, now);
    let next = birthdayIn(now.y, birth);
    if (compare(next, now) < 0) next = birthdayIn(now.y + 1, birth);
    const untilNext = totalDaysBetween(now, next);
    const turning = next.y - birth.y;
    return {
      age,
      totalDays,
      untilNext,
      turning,
      nextDate: next,
      bornOn: weekday(birth),
      birth,
    };
  }, [dob, today]);

  return (
    <div className="space-y-5">
      <DateField label="Date of birth" value={dob} onChange={setDob} />

      {'error' in result ? (
        <Notice>{result.error}</Notice>
      ) : (
        <>
          <ResultHero
            label="Your exact age"
            value={
              <span>
                {result.age.years}
                <span className="text-lg font-medium text-violet-100"> years</span>
              </span>
            }
            sub={`${plural(result.age.months, 'month')}, ${plural(result.age.days, 'day')}`}
          />

          {result.untilNext === 0 ? (
            <div className="flex items-center gap-3 rounded-2xl bg-pink-50 p-4 text-pink-600">
              <PartyPopper size={22} />
              <p className="text-sm font-semibold">Happy birthday! You turn {result.turning} today 🎉</p>
            </div>
          ) : (
            <div className="rounded-2xl bg-violet-50 p-4">
              <div className="flex items-baseline justify-between">
                <p className="text-xs font-medium uppercase tracking-wide text-violet-500">Next birthday</p>
                <p className="text-xs text-violet-400">Turning {result.turning}</p>
              </div>
              <p className="mt-1 text-xl font-bold text-violet-700">in {plural(result.untilNext, 'day')}</p>
              <p className="text-xs text-violet-400">{formatLong(result.nextDate)}</p>
              <div className="mt-3 h-2 overflow-hidden rounded-full bg-white">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-violet-400 to-purple-600 transition-all duration-500"
                  style={{ width: `${Math.max(2, 100 - (result.untilNext / 365) * 100)}%` }}
                />
              </div>
            </div>
          )}

          <div className="grid grid-cols-2 gap-3">
            <Stat label="Total days lived" value={int(result.totalDays)} accent="text-violet-600" />
            <Stat label="Born on a" value={result.bornOn} />
            <Stat label="Weeks lived" value={int(Math.floor(result.totalDays / 7))} />
            <Stat label="Months lived" value={int(result.age.years * 12 + result.age.months)} />
            <Stat label="Hours lived" value={int(result.totalDays * 24)} />
            <Stat label="Heartbeats (≈)" value={int(result.totalDays * 24 * 60 * 80)} />
          </div>
        </>
      )}
    </div>
  );
}
