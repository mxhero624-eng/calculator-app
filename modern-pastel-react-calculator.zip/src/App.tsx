import { useState } from 'react';
import { Calculator, LayoutGrid } from 'lucide-react';
import StandardCalculator from './components/StandardCalculator';
import ToolsHub from './components/ToolsHub';

type Tab = 'standard' | 'tools';

export default function App() {
  const [tab, setTab] = useState<Tab>('standard');

  return (
    <div className="min-h-screen w-full bg-gradient-to-br from-[#FFE4EA] via-[#FFECEF] to-[#FFF0F3] font-sans text-gray-800 antialiased">
      {/* soft decorative blobs */}
      <div className="pointer-events-none fixed -left-24 -top-24 h-72 w-72 rounded-full bg-violet-200/40 blur-3xl" />
      <div className="pointer-events-none fixed -bottom-24 -right-24 h-80 w-80 rounded-full bg-pink-200/60 blur-3xl" />

      <div className="relative mx-auto flex min-h-screen max-w-6xl flex-col items-center justify-center px-3 py-6 sm:px-6 sm:py-10">
        <header className="mb-6 flex w-full max-w-[420px] items-center gap-3 lg:max-w-2xl">
          <span className="text-xl font-bold tracking-tight text-violet-600">DailyUI</span>
          <span className="h-0.5 flex-1 rounded-full bg-violet-400/70" />
          <span className="text-xl font-bold text-violet-600">#004</span>
        </header>

        <main className="w-full max-w-[420px] rounded-3xl bg-white p-5 shadow-[0_20px_60px_rgba(0,0,0,0.08)] sm:p-7">
          {/* Tab bar */}
          <nav className="relative mb-6 grid grid-cols-2 rounded-full bg-gray-50 p-1.5 shadow-[inset_0_1px_3px_rgba(0,0,0,0.05)]" role="tablist">
            <span
              className="absolute bottom-1.5 left-1.5 top-1.5 w-[calc(50%-6px)] rounded-full bg-gradient-to-r from-violet-500 to-purple-600 shadow-[0_6px_16px_rgba(139,92,246,0.4)] transition-transform duration-300 ease-out"
              style={{ transform: tab === 'tools' ? 'translateX(100%)' : 'translateX(0)' }}
            />
            {(
              [
                { id: 'standard', label: 'Standard', icon: Calculator },
                { id: 'tools', label: 'Tools', icon: LayoutGrid },
              ] as const
            ).map(({ id, label, icon: Icon }) => (
              <button
                key={id}
                role="tab"
                aria-selected={tab === id}
                type="button"
                onClick={() => setTab(id)}
                className={`relative z-10 flex items-center justify-center gap-2 rounded-full py-2.5 text-sm font-semibold transition-colors duration-200 ${
                  tab === id ? 'text-white' : 'text-gray-400 hover:text-violet-500'
                }`}
              >
                <Icon size={16} />
                {label}
              </button>
            ))}
          </nav>

          <div key={tab} className="animate-fade-up">
            {tab === 'standard' ? <StandardCalculator /> : <ToolsHub />}
          </div>
        </main>

        <p className="mt-6 text-center text-xs text-violet-400/80">
          Calculator & multi-tool hub · runs entirely in your browser
        </p>
      </div>
    </div>
  );
}
