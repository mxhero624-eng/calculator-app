import { useCallback, useEffect, useMemo, useReducer, useState } from 'react';
import { Delete, Divide, Equal, History, Minus, Percent, Plus, Trash2, X } from 'lucide-react';
import { CalcError, evaluateTokens, formatRaw, numberToRaw, type Op } from '../lib/calcEngine';
import { cx } from './ui';

interface HistoryEntry {
  expr: string;
  result: string;
}

interface State {
  tokens: string[]; // alternating raw number strings and operators
  current: string; // raw string being typed ('' = awaiting operand)
  evaluated: boolean;
  error: boolean;
  lastExpr: string;
  history: HistoryEntry[];
}

type Action =
  | { type: 'digit'; d: string }
  | { type: 'dot' }
  | { type: 'op'; op: Op }
  | { type: 'equals' }
  | { type: 'clear' }
  | { type: 'sign' }
  | { type: 'percent' }
  | { type: 'back' }
  | { type: 'load'; value: string }
  | { type: 'clearHistory' };

const initial: State = { tokens: [], current: '0', evaluated: false, error: false, lastExpr: '', history: [] };
const MAX_DIGITS = 15;

const isOp = (t: string): t is Op => t === '+' || t === '−' || t === '×' || t === '÷';

function toTokens(list: string[]): (number | Op)[] {
  return list.map((t) => (isOp(t) ? t : Number(t)));
}

function normalize(raw: string): string {
  if (raw === '' || raw === '-' || raw === '-0') return '0';
  const n = Number(raw);
  return Number.isFinite(n) ? numberToRaw(n) : '0';
}

function exprString(list: string[]): string {
  return list.map((t) => (isOp(t) ? ` ${t} ` : formatRaw(t))).join('').trim();
}

function reducer(s: State, a: Action): State {
  const fresh = { ...initial, history: s.history };
  switch (a.type) {
    case 'digit': {
      if (s.error || s.evaluated) return { ...fresh, current: a.d };
      let c = s.current;
      if (c.replace(/\D/g, '').length >= MAX_DIGITS) return s;
      if (c === '0') c = a.d;
      else if (c === '-0') c = '-' + a.d;
      else c = c + a.d;
      return { ...s, current: c };
    }
    case 'dot': {
      if (s.error || s.evaluated) return { ...fresh, current: '0.' };
      if (s.current.includes('.') || /e/i.test(s.current)) return s;
      return { ...s, current: s.current === '' ? '0.' : s.current + '.' };
    }
    case 'op': {
      if (s.error) return s;
      if (s.current === '') {
        if (s.tokens.length === 0) return s;
        return { ...s, tokens: [...s.tokens.slice(0, -1), a.op] };
      }
      return { ...s, tokens: [...s.tokens, normalize(s.current), a.op], current: '', evaluated: false, lastExpr: '' };
    }
    case 'equals': {
      if (s.error) return s;
      const toks = [...s.tokens];
      if (toks.length === 0) return s;
      if (s.current === '') toks.pop();
      else toks.push(normalize(s.current));
      const expr = exprString(toks);
      try {
        const result = evaluateTokens(toTokens(toks));
        const raw = numberToRaw(result);
        return {
          ...s,
          tokens: [],
          current: raw,
          evaluated: true,
          lastExpr: `${expr} =`,
          history: [{ expr, result: raw }, ...s.history].slice(0, 30),
        };
      } catch (e) {
        if (e instanceof CalcError) {
          return { ...fresh, current: 'Error', error: true, lastExpr: `${expr} =` };
        }
        throw e;
      }
    }
    case 'clear':
      return fresh;
    case 'sign': {
      if (s.error) return s;
      if (s.current === '') return { ...s, current: '-0' };
      const c = s.current.startsWith('-') ? s.current.slice(1) : '-' + s.current;
      return { ...s, current: c };
    }
    case 'percent': {
      if (s.error || s.current === '') return s;
      const value = Number(s.current);
      if (!Number.isFinite(value)) return s;
      const lastOp = s.tokens[s.tokens.length - 1];
      let pct = value / 100;
      // Contextual percent: 200 + 10% => 200 + 20
      if (lastOp === '+' || lastOp === '−') {
        try {
          const base = evaluateTokens(toTokens(s.tokens.slice(0, -1)));
          pct = (base * value) / 100;
        } catch {
          /* fall back to value / 100 */
        }
      }
      return { ...s, current: numberToRaw(pct), evaluated: false };
    }
    case 'back': {
      if (s.error || s.evaluated) return fresh;
      if (s.current !== '') {
        let c = /e/i.test(s.current) ? '' : s.current.slice(0, -1);
        if (c === '' || c === '-') c = s.tokens.length ? '' : '0';
        return { ...s, current: c };
      }
      if (s.tokens.length) {
        const t = [...s.tokens];
        t.pop(); // operator
        const last = t.pop() ?? '0';
        return { ...s, tokens: t, current: last };
      }
      return s;
    }
    case 'load':
      return { ...fresh, current: a.value, evaluated: true };
    case 'clearHistory':
      return { ...s, history: [] };
  }
}

function displaySize(len: number) {
  if (len <= 9) return 'text-5xl';
  if (len <= 12) return 'text-4xl';
  if (len <= 16) return 'text-3xl';
  return 'text-2xl';
}

export default function StandardCalculator() {
  const [s, dispatch] = useReducer(reducer, initial);
  const [showHistory, setShowHistory] = useState(false);
  const [pressed, setPressed] = useState<string | null>(null);

  // Running value shown in main display while waiting for next operand
  const mainDisplay = useMemo(() => {
    if (s.error) return 'Error';
    if (s.current !== '') return formatRaw(s.current);
    try {
      return formatRaw(numberToRaw(evaluateTokens(toTokens(s.tokens.slice(0, -1)))));
    } catch {
      return 'Error';
    }
  }, [s]);

  const expression = useMemo(() => {
    if (s.lastExpr) return s.lastExpr;
    const parts = [...s.tokens];
    if (s.current !== '' && s.tokens.length) parts.push(s.current);
    return exprString(parts);
  }, [s]);

  // Live preview of the result while typing a chained expression
  const preview = useMemo(() => {
    if (s.error || s.evaluated || s.current === '' || s.tokens.length === 0) return '';
    try {
      return formatRaw(numberToRaw(evaluateTokens(toTokens([...s.tokens, normalize(s.current)]))));
    } catch {
      return 'Error';
    }
  }, [s]);

  const activeOp = s.current === '' && s.tokens.length ? (s.tokens[s.tokens.length - 1] as Op) : null;

  const flash = useCallback((key: string) => {
    setPressed(key);
    window.setTimeout(() => setPressed((p) => (p === key ? null : p)), 140);
  }, []);

  // Keyboard support
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement | null;
      if (target && (target.tagName === 'INPUT' || target.tagName === 'SELECT' || target.tagName === 'TEXTAREA')) return;
      if (e.ctrlKey || e.metaKey || e.altKey) return;
      const k = e.key;
      let handled = true;
      if (/^\d$/.test(k)) {
        dispatch({ type: 'digit', d: k });
        flash(k);
      } else if (k === '.' || k === ',') {
        dispatch({ type: 'dot' });
        flash('.');
      } else if (k === '+') {
        dispatch({ type: 'op', op: '+' });
        flash('+');
      } else if (k === '-') {
        dispatch({ type: 'op', op: '−' });
        flash('−');
      } else if (k === '*' || k.toLowerCase() === 'x') {
        dispatch({ type: 'op', op: '×' });
        flash('×');
      } else if (k === '/') {
        dispatch({ type: 'op', op: '÷' });
        flash('÷');
      } else if (k === 'Enter' || k === '=') {
        dispatch({ type: 'equals' });
        flash('=');
      } else if (k === 'Backspace') {
        dispatch({ type: 'back' });
        flash('back');
      } else if (k === 'Escape' || k === 'Delete' || k.toLowerCase() === 'c') {
        dispatch({ type: 'clear' });
        flash('AC');
      } else if (k === '%') {
        dispatch({ type: 'percent' });
        flash('%');
      } else if (k === 'F9') {
        dispatch({ type: 'sign' });
        flash('±');
      } else handled = false;
      if (handled) e.preventDefault();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [flash]);

  type Variant = 'num' | 'op' | 'fn' | 'clear' | 'equals';
  const keys: { key: string; label: React.ReactNode; action: Action; variant: Variant; span?: boolean; aria: string }[] = [
    { key: 'AC', label: 'AC', action: { type: 'clear' }, variant: 'clear', aria: 'All clear' },
    { key: '±', label: '±', action: { type: 'sign' }, variant: 'fn', aria: 'Toggle sign' },
    { key: '%', label: <Percent size={20} />, action: { type: 'percent' }, variant: 'fn', aria: 'Percent' },
    { key: '÷', label: <Divide size={22} />, action: { type: 'op', op: '÷' }, variant: 'op', aria: 'Divide' },
    { key: '7', label: '7', action: { type: 'digit', d: '7' }, variant: 'num', aria: '7' },
    { key: '8', label: '8', action: { type: 'digit', d: '8' }, variant: 'num', aria: '8' },
    { key: '9', label: '9', action: { type: 'digit', d: '9' }, variant: 'num', aria: '9' },
    { key: '×', label: <X size={22} />, action: { type: 'op', op: '×' }, variant: 'op', aria: 'Multiply' },
    { key: '4', label: '4', action: { type: 'digit', d: '4' }, variant: 'num', aria: '4' },
    { key: '5', label: '5', action: { type: 'digit', d: '5' }, variant: 'num', aria: '5' },
    { key: '6', label: '6', action: { type: 'digit', d: '6' }, variant: 'num', aria: '6' },
    { key: '−', label: <Minus size={22} />, action: { type: 'op', op: '−' }, variant: 'op', aria: 'Subtract' },
    { key: '1', label: '1', action: { type: 'digit', d: '1' }, variant: 'num', aria: '1' },
    { key: '2', label: '2', action: { type: 'digit', d: '2' }, variant: 'num', aria: '2' },
    { key: '3', label: '3', action: { type: 'digit', d: '3' }, variant: 'num', aria: '3' },
    { key: '+', label: <Plus size={22} />, action: { type: 'op', op: '+' }, variant: 'op', aria: 'Add' },
    { key: '0', label: '0', action: { type: 'digit', d: '0' }, variant: 'num', span: true, aria: '0' },
    { key: '.', label: '.', action: { type: 'dot' }, variant: 'num', aria: 'Decimal point' },
    { key: '=', label: <Equal size={24} />, action: { type: 'equals' }, variant: 'equals', aria: 'Equals' },
  ];

  const variantClass = (v: Variant, key: string) => {
    if (v === 'op' && activeOp === key)
      return 'bg-violet-500 text-white shadow-[0_8px_18px_rgba(139,92,246,0.4)]';
    switch (v) {
      case 'num':
        return 'bg-gray-50 text-gray-700 shadow-[0_4px_10px_rgba(0,0,0,0.04)] hover:bg-white';
      case 'op':
        return 'bg-violet-50 text-violet-600 shadow-[0_4px_10px_rgba(139,92,246,0.08)] hover:bg-violet-100';
      case 'fn':
        return 'bg-violet-50/60 text-violet-500 shadow-[0_4px_10px_rgba(139,92,246,0.06)] hover:bg-violet-100';
      case 'clear':
        return 'bg-rose-50 text-rose-500 shadow-[0_4px_10px_rgba(244,63,94,0.08)] hover:bg-rose-100';
      case 'equals':
        return 'bg-gradient-to-br from-violet-500 to-purple-600 text-white font-bold shadow-[0_10px_22px_rgba(139,92,246,0.45)] hover:from-violet-600 hover:to-purple-700';
    }
  };

  return (
    <div className="flex flex-col gap-5">
      {/* Display */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-b from-violet-50/80 to-pink-50/40 px-5 pb-4 pt-3">
        <div className="flex items-center justify-between">
          <button
            type="button"
            onClick={() => setShowHistory((v) => !v)}
            aria-label="Toggle history"
            className={cx(
              'flex h-9 items-center gap-1.5 rounded-xl px-2.5 text-xs font-semibold transition-all duration-200 active:scale-95',
              showHistory ? 'bg-violet-500 text-white' : 'text-violet-500 hover:bg-violet-100',
            )}
          >
            <History size={16} />
            {s.history.length > 0 && <span>{s.history.length}</span>}
          </button>
          <button
            type="button"
            onClick={() => {
              dispatch({ type: 'back' });
              flash('back');
            }}
            aria-label="Backspace"
            className={cx(
              'flex h-9 w-9 items-center justify-center rounded-xl text-violet-500 transition-all duration-150 hover:bg-violet-100 active:scale-90',
              pressed === 'back' && 'scale-90 bg-violet-100',
            )}
          >
            <Delete size={20} />
          </button>
        </div>

        {showHistory ? (
          <div className="mt-2 h-[132px] overflow-y-auto pr-1">
            {s.history.length === 0 ? (
              <p className="flex h-full items-center justify-center text-sm text-gray-400">No calculations yet</p>
            ) : (
              <>
                <ul className="space-y-1">
                  {s.history.map((h, i) => (
                    <li key={i}>
                      <button
                        type="button"
                        onClick={() => {
                          dispatch({ type: 'load', value: h.result });
                          setShowHistory(false);
                        }}
                        className="w-full rounded-xl px-2 py-1.5 text-right transition-all duration-150 hover:bg-white/80"
                      >
                        <p className="truncate text-xs text-gray-400">{h.expr} =</p>
                        <p className="truncate text-base font-semibold text-gray-700">{formatRaw(h.result)}</p>
                      </button>
                    </li>
                  ))}
                </ul>
                <button
                  type="button"
                  onClick={() => dispatch({ type: 'clearHistory' })}
                  className="mx-auto mt-2 flex items-center gap-1 rounded-lg px-2 py-1 text-xs font-semibold text-rose-400 hover:bg-rose-50"
                >
                  <Trash2 size={12} /> Clear history
                </button>
              </>
            )}
          </div>
        ) : (
          <div className="mt-2 flex h-[132px] flex-col items-end justify-end text-right">
            {s.history.slice(0, 2).reverse().map((h, i) => (
              <p key={i} className="max-w-full truncate text-xs text-gray-300">
                {h.expr} = {formatRaw(h.result)}
              </p>
            ))}
            <p className="mt-1 min-h-[20px] max-w-full truncate text-sm text-gray-400">{expression || '\u00a0'}</p>
            <p
              aria-live="polite"
              className={cx(
                'max-w-full truncate font-light tracking-tight transition-all duration-200',
                displaySize(mainDisplay.length),
                s.error ? 'text-rose-500' : 'text-gray-900',
              )}
            >
              {s.evaluated && !s.error && <span className="mr-1 text-violet-500">=</span>}
              {mainDisplay}
            </p>
            <p className="h-5 text-sm font-medium text-violet-400">{preview && `= ${preview}`}</p>
          </div>
        )}
      </div>

      {/* Keypad */}
      <div className="grid grid-cols-4 gap-3">
        {keys.map((k) => (
          <button
            key={k.key}
            type="button"
            aria-label={k.aria}
            onClick={() => dispatch(k.action)}
            className={cx(
              'flex min-h-[56px] items-center justify-center rounded-2xl text-xl font-semibold transition-all duration-150 select-none hover:scale-[1.05] active:scale-95 sm:min-h-[62px]',
              k.span && 'col-span-2',
              variantClass(k.variant, k.key),
              pressed === k.key && 'scale-95 brightness-95',
            )}
          >
            {k.label}
          </button>
        ))}
      </div>

      <p className="hidden text-center text-[11px] text-gray-400 sm:block">
        Keyboard: 0–9 · + − * / · Enter · Backspace · Esc · %
      </p>
    </div>
  );
}
