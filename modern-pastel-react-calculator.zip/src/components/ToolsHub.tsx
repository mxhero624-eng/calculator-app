import { type ComponentType, useState } from 'react';
import {
  Activity,
  ArrowLeft,
  ArrowLeftRight,
  Cake,
  Calendar,
  PiggyBank,
  Ruler,
  Thermometer,
  TrendingUp,
  type LucideIcon,
} from 'lucide-react';
import BmiCalculator from '../tools/BmiCalculator';
import CurrencyConverter from '../tools/CurrencyConverter';
import DateCalculator from '../tools/DateCalculator';
import InvestmentCalculator from '../tools/InvestmentCalculator';
import AgeCalculator from '../tools/AgeCalculator';
import SavingsCalculator from '../tools/SavingsCalculator';
import UnitConverter from '../tools/UnitConverter';
import TemperatureConverter from '../tools/TemperatureConverter';

interface Tool {
  id: string;
  name: string;
  title: string;
  description: string;
  icon: LucideIcon;
  component: ComponentType;
}

export const TOOLS: Tool[] = [
  { id: 'bmi', name: 'BMI', title: 'BMI Calculator', description: 'Body mass index', icon: Activity, component: BmiCalculator },
  { id: 'currency', name: 'Currency', title: 'Currency Converter', description: '10 world currencies', icon: ArrowLeftRight, component: CurrencyConverter },
  { id: 'date', name: 'Date', title: 'Date Calculator', description: 'Differences & offsets', icon: Calendar, component: DateCalculator },
  { id: 'invest', name: 'Invest', title: 'Investment Calc', description: 'Compound growth', icon: TrendingUp, component: InvestmentCalculator },
  { id: 'age', name: 'Age', title: 'Age Calculator', description: 'Exact age & birthday', icon: Cake, component: AgeCalculator },
  { id: 'savings', name: 'Savings', title: 'Savings Goal', description: 'Time to reach a goal', icon: PiggyBank, component: SavingsCalculator },
  { id: 'unit', name: 'Units', title: 'Unit Converter', description: 'Length, weight & more', icon: Ruler, component: UnitConverter },
  { id: 'temp', name: 'Temp.', title: 'Temperature', description: '°C · °F · K', icon: Thermometer, component: TemperatureConverter },
];

export default function ToolsHub() {
  const [activeId, setActiveId] = useState<string | null>(null);
  const [lastId, setLastId] = useState<string | null>(null);
  const active = TOOLS.find((t) => t.id === activeId);

  if (active) {
    const Comp = active.component;
    const Icon = active.icon;
    return (
      <div key={active.id} className="animate-fade-up">
        <div className="mb-5 flex items-center gap-3">
          <button
            type="button"
            aria-label="Back to tools"
            onClick={() => setActiveId(null)}
            className="flex h-10 w-10 items-center justify-center rounded-2xl bg-gray-50 text-gray-700 shadow-sm transition-all duration-200 hover:scale-105 hover:bg-violet-50 hover:text-violet-600 active:scale-95"
          >
            <ArrowLeft size={20} />
          </button>
          <h2 className="flex-1 text-center text-base font-semibold text-gray-800">{active.title}</h2>
          <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-violet-100 text-violet-600">
            <Icon size={18} />
          </div>
        </div>
        <Comp />
      </div>
    );
  }

  return (
    <div className="grid grid-cols-2 gap-3 animate-fade-up sm:gap-4">
      {TOOLS.map((t) => {
        const Icon = t.icon;
        const highlighted = t.id === lastId;
        return (
          <button
            key={t.id}
            type="button"
            onClick={() => {
              setLastId(t.id);
              setActiveId(t.id);
            }}
            className={`group flex aspect-[1/0.95] flex-col items-center justify-center gap-2 rounded-2xl p-3 text-center transition-all duration-200 hover:-translate-y-1 hover:scale-[1.03] active:scale-95 ${
              highlighted
                ? 'bg-gradient-to-br from-violet-500 to-purple-600 text-white shadow-[0_14px_30px_rgba(139,92,246,0.4)]'
                : 'bg-white text-gray-600 shadow-[0_8px_24px_rgba(0,0,0,0.06)] ring-1 ring-gray-100 hover:text-violet-600 hover:shadow-[0_14px_30px_rgba(139,92,246,0.18)] hover:ring-violet-200'
            }`}
          >
            <div
              className={`flex h-11 w-11 items-center justify-center rounded-2xl transition-all duration-200 group-hover:rotate-[-6deg] ${
                highlighted ? 'bg-white/20' : 'bg-violet-50 text-violet-500 group-hover:bg-violet-100'
              }`}
            >
              <Icon size={22} strokeWidth={2} />
            </div>
            <span className="text-sm font-medium">{t.name}</span>
            <span className={`line-clamp-1 text-[11px] ${highlighted ? 'text-violet-100' : 'text-gray-400'}`}>
              {t.description}
            </span>
          </button>
        );
      })}
    </div>
  );
}
