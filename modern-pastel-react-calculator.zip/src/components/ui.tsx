import { type ReactNode, useId } from 'react';
import { ArrowLeftRight, ChevronDown, Minus, Plus } from 'lucide-react';

export function cx(...classes: (string | false | null | undefined)[]) {
  return classes.filter(Boolean).join(' ');
}

export function Label({ children, htmlFor }: { children: ReactNode; htmlFor?: string }) {
  return (
    <label htmlFor={htmlFor} className="mb-1.5 block text-xs font-medium uppercase tracking-wide text-gray-500">
      {children}
    </label>
  );
}

interface NumberFieldProps {
  label: string;
  value: string;
  onChange: (v: string) => void;
  prefix?: string;
  suffix?: string;
  min?: number;
  max?: number;
  step?: number;
  allowNegative?: boolean;
  placeholder?: string;
  stepper?: boolean;
}

/** Controlled numeric text input that accepts partial input (e.g. "12." or "-"). */
export function NumberField({
  label,
  value,
  onChange,
  prefix,
  suffix,
  min,
  max,
  step = 1,
  allowNegative = false,
  placeholder = '0',
  stepper = false,
}: NumberFieldProps) {
  const id = useId();
  const pattern = allowNegative ? /^-?\d*\.?\d*$/ : /^\d*\.?\d*$/;

  const handle = (raw: string) => {
    const v = raw.replace(/,/g, '');
    if (v === '' || pattern.test(v)) onChange(v);
  };

  const bump = (dir: 1 | -1) => {
    const cur = Number.parseFloat(value) || 0;
    let next = Number.parseFloat((cur + dir * step).toPrecision(12));
    if (min !== undefined) next = Math.max(min, next);
    if (max !== undefined) next = Math.min(max, next);
    onChange(String(next));
  };

  return (
    <div>
      <Label htmlFor={id}>{label}</Label>
      <div className="group flex items-center gap-2 rounded-2xl border-2 border-transparent bg-gray-50 px-3 transition-all duration-200 focus-within:border-violet-400 focus-within:bg-white focus-within:shadow-[0_0_0_4px_rgba(139,92,246,0.1)]">
        {stepper && (
          <button
            type="button"
            aria-label={`Decrease ${label}`}
            onClick={() => bump(-1)}
            className="flex h-8 w-8 shrink-0 items-center justify-center rounded-xl bg-white text-violet-600 shadow-sm transition-all duration-150 hover:bg-violet-50 active:scale-90"
          >
            <Minus size={16} />
          </button>
        )}
        {prefix && <span className="text-sm font-medium text-gray-400">{prefix}</span>}
        <input
          id={id}
          inputMode="decimal"
          autoComplete="off"
          value={value}
          placeholder={placeholder}
          onChange={(e) => handle(e.target.value)}
          className={cx(
            'h-12 w-full min-w-0 bg-transparent text-base font-semibold text-gray-800 outline-none placeholder:text-gray-300',
            stepper && 'text-center',
          )}
        />
        {suffix && <span className="shrink-0 text-sm font-medium text-gray-400">{suffix}</span>}
        {stepper && (
          <button
            type="button"
            aria-label={`Increase ${label}`}
            onClick={() => bump(1)}
            className="flex h-8 w-8 shrink-0 items-center justify-center rounded-xl bg-white text-violet-600 shadow-sm transition-all duration-150 hover:bg-violet-50 active:scale-90"
          >
            <Plus size={16} />
          </button>
        )}
      </div>
    </div>
  );
}

interface SliderProps {
  value: number;
  onChange: (v: number) => void;
  min: number;
  max: number;
  step?: number;
  label?: string;
}

export function Slider({ value, onChange, min, max, step = 1, label }: SliderProps) {
  const clamped = Math.min(max, Math.max(min, Number.isFinite(value) ? value : min));
  const pct = ((clamped - min) / (max - min)) * 100;
  return (
    <input
      type="range"
      aria-label={label}
      min={min}
      max={max}
      step={step}
      value={clamped}
      onChange={(e) => onChange(Number(e.target.value))}
      className="mt-3 h-2 w-full cursor-pointer appearance-none rounded-full accent-violet-500"
      style={{
        background: `linear-gradient(to right, #8B5CF6 0%, #A78BFA ${pct}%, #EDE9FE ${pct}%, #EDE9FE 100%)`,
      }}
    />
  );
}

interface SegmentedProps<T extends string> {
  options: { value: T; label: ReactNode }[];
  value: T;
  onChange: (v: T) => void;
  size?: 'sm' | 'md';
}

export function Segmented<T extends string>({ options, value, onChange, size = 'md' }: SegmentedProps<T>) {
  return (
    <div className="flex gap-1 rounded-2xl bg-violet-50 p-1">
      {options.map((o) => {
        const active = o.value === value;
        return (
          <button
            key={o.value}
            type="button"
            onClick={() => onChange(o.value)}
            className={cx(
              'flex-1 rounded-xl font-semibold transition-all duration-200 active:scale-95',
              size === 'sm' ? 'py-1.5 text-xs' : 'py-2 text-sm',
              active
                ? 'bg-violet-500 text-white shadow-[0_4px_12px_rgba(139,92,246,0.35)]'
                : 'text-gray-500 hover:text-violet-600',
            )}
          >
            {o.label}
          </button>
        );
      })}
    </div>
  );
}

interface SelectFieldProps {
  label: string;
  value: string;
  onChange: (v: string) => void;
  options: { value: string; label: string }[];
}

export function SelectField({ label, value, onChange, options }: SelectFieldProps) {
  const id = useId();
  return (
    <div className="min-w-0">
      <Label htmlFor={id}>{label}</Label>
      <div className="relative">
        <select
          id={id}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="h-12 w-full cursor-pointer appearance-none rounded-2xl border-2 border-transparent bg-gray-50 pl-3 pr-9 text-sm font-semibold text-gray-800 outline-none transition-all duration-200 focus:border-violet-400 focus:bg-white"
        >
          {options.map((o) => (
            <option key={o.value} value={o.value}>
              {o.label}
            </option>
          ))}
        </select>
        <ChevronDown size={16} className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" />
      </div>
    </div>
  );
}

export function DateField({ label, value, onChange }: { label: string; value: string; onChange: (v: string) => void }) {
  const id = useId();
  return (
    <div className="min-w-0">
      <Label htmlFor={id}>{label}</Label>
      <input
        id={id}
        type="date"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="h-12 w-full rounded-2xl border-2 border-transparent bg-gray-50 px-3 text-sm font-semibold text-gray-800 outline-none transition-all duration-200 [color-scheme:light] focus:border-violet-400 focus:bg-white"
      />
    </div>
  );
}

/** Big purple result card. */
export function ResultHero({ label, value, sub, children }: { label: string; value: ReactNode; sub?: ReactNode; children?: ReactNode }) {
  return (
    <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-violet-500 to-purple-600 p-5 text-white shadow-[0_12px_30px_rgba(139,92,246,0.35)]">
      <div className="pointer-events-none absolute -right-8 -top-8 h-28 w-28 rounded-full bg-white/10" />
      <div className="pointer-events-none absolute -bottom-10 -left-6 h-24 w-24 rounded-full bg-white/10" />
      <p className="relative text-xs font-medium uppercase tracking-wide text-violet-100">{label}</p>
      <div className="relative mt-1 break-words text-3xl font-bold tracking-tight sm:text-4xl">{value}</div>
      {sub && <div className="relative mt-1 text-sm text-violet-100">{sub}</div>}
      {children && <div className="relative mt-3">{children}</div>}
    </div>
  );
}

export function Stat({ label, value, accent }: { label: string; value: ReactNode; accent?: string }) {
  return (
    <div className="rounded-2xl bg-gray-50 p-3 transition-all duration-200 hover:bg-violet-50/60">
      <p className="text-[11px] font-medium uppercase tracking-wide text-gray-400">{label}</p>
      <p className={cx('mt-0.5 break-words text-base font-bold text-gray-800', accent)}>{value}</p>
    </div>
  );
}

export function Notice({ children, tone = 'warn' }: { children: ReactNode; tone?: 'warn' | 'info' }) {
  return (
    <div
      className={cx(
        'rounded-2xl px-4 py-3 text-sm font-medium',
        tone === 'warn' ? 'bg-rose-50 text-rose-500' : 'bg-violet-50 text-violet-600',
      )}
    >
      {children}
    </div>
  );
}

export function SwapButton({ onClick, label = 'Swap' }: { onClick: () => void; label?: string }) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-label={label}
      className="group flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-violet-500 text-white shadow-[0_6px_16px_rgba(139,92,246,0.35)] transition-all duration-200 hover:scale-105 hover:bg-violet-600 active:scale-95"
    >
      <ArrowLeftRight size={18} className="transition-transform duration-300 group-hover:rotate-180" />
    </button>
  );
}
