const DAY_MS = 86_400_000;

export interface YMD {
  y: number;
  m: number; // 1-12
  d: number;
}

/** Parse "YYYY-MM-DD" without timezone side effects. */
export function parseISO(s: string): YMD | null {
  const match = /^(\d{4,})-(\d{2})-(\d{2})$/.exec(s);
  if (!match) return null;
  const y = Number(match[1]);
  const m = Number(match[2]);
  const d = Number(match[3]);
  if (m < 1 || m > 12 || d < 1 || d > daysInMonth(y, m)) return null;
  return { y, m, d };
}

export function toISO(date: YMD): string {
  return `${String(date.y).padStart(4, '0')}-${String(date.m).padStart(2, '0')}-${String(date.d).padStart(2, '0')}`;
}

export function todayISO(): string {
  const n = new Date();
  return toISO({ y: n.getFullYear(), m: n.getMonth() + 1, d: n.getDate() });
}

export function daysInMonth(y: number, m: number): number {
  return new Date(Date.UTC(y, m, 0)).getUTCDate();
}

export function isLeap(y: number) {
  return (y % 4 === 0 && y % 100 !== 0) || y % 400 === 0;
}

export function toUTC(d: YMD): number {
  const dt = new Date(Date.UTC(2000, d.m - 1, d.d));
  dt.setUTCFullYear(d.y);
  return dt.getTime();
}

export function fromUTC(ms: number): YMD {
  const dt = new Date(ms);
  return { y: dt.getUTCFullYear(), m: dt.getUTCMonth() + 1, d: dt.getUTCDate() };
}

export function compare(a: YMD, b: YMD) {
  return toUTC(a) - toUTC(b);
}

export function totalDaysBetween(a: YMD, b: YMD): number {
  return Math.round((toUTC(b) - toUTC(a)) / DAY_MS);
}

/** Calendar difference in years / months / days (a <= b). */
export function diffYMD(a: YMD, b: YMD): { years: number; months: number; days: number } {
  // Find the largest number of whole months that fits, then count remaining days.
  let total = (b.y - a.y) * 12 + (b.m - a.m);
  let anchor = addMonthsClamped(a, total);
  if (compare(anchor, b) > 0) {
    total -= 1;
    anchor = addMonthsClamped(a, total);
  }
  const days = totalDaysBetween(anchor, b);
  return { years: Math.floor(total / 12), months: total % 12, days };
}

/** Add months, clamping the day to the end of the target month (Jan 31 + 1 month = Feb 28/29). */
export function addMonthsClamped(d: YMD, n: number): YMD {
  const idx = d.y * 12 + (d.m - 1) + n;
  const y = Math.floor(idx / 12);
  const m = (idx % 12) + 1;
  return { y, m, d: Math.min(d.d, daysInMonth(y, m)) };
}

export function addDays(d: YMD, n: number): YMD {
  return fromUTC(toUTC(d) + n * DAY_MS);
}

export const WEEKDAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

export function weekday(d: YMD): string {
  return WEEKDAYS[new Date(toUTC(d)).getUTCDay()];
}

export function formatLong(d: YMD): string {
  return new Date(toUTC(d)).toLocaleDateString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    timeZone: 'UTC',
  });
}
