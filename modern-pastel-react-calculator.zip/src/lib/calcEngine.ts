export type Op = '+' | '−' | '×' | '÷';
export const OPS: Op[] = ['+', '−', '×', '÷'];

export class CalcError extends Error {}

/**
 * Safely evaluate an alternating list [num, op, num, op, num ...]
 * respecting operator precedence (× ÷ before + −). No eval().
 */
export function evaluateTokens(tokens: (number | Op)[]): number {
  if (tokens.length === 0) return 0;
  // Pass 1: multiplication & division
  const stack: (number | Op)[] = [tokens[0] as number];
  for (let i = 1; i < tokens.length; i += 2) {
    const op = tokens[i] as Op;
    const right = tokens[i + 1] as number;
    if (right === undefined) break;
    if (op === '×' || op === '÷') {
      const left = stack.pop() as number;
      if (op === '÷' && right === 0) throw new CalcError('Division by zero');
      stack.push(op === '×' ? left * right : left / right);
    } else {
      stack.push(op, right);
    }
  }
  // Pass 2: addition & subtraction
  let result = stack[0] as number;
  for (let i = 1; i < stack.length; i += 2) {
    const op = stack[i] as Op;
    const right = stack[i + 1] as number;
    result = op === '+' ? result + right : result - right;
  }
  if (!Number.isFinite(result)) throw new CalcError('Overflow');
  return Number.parseFloat(result.toPrecision(12));
}

/** Convert a number to a compact raw string suitable for further input. */
export function numberToRaw(n: number): string {
  if (Object.is(n, -0)) return '0';
  const abs = Math.abs(n);
  if (abs !== 0 && (abs >= 1e16 || abs < 1e-9)) return n.toExponential(8).replace(/\.?0+e/, 'e');
  return String(Number.parseFloat(n.toPrecision(12)));
}

/** Add thousands separators to a raw input string while preserving trailing "." and zeros. */
export function formatRaw(raw: string): string {
  if (raw === '' || raw === 'Error') return raw;
  if (/e/i.test(raw)) return raw;
  const negative = raw.startsWith('-');
  const body = negative ? raw.slice(1) : raw;
  const [intPart, decPart] = body.split('.');
  const withCommas = (intPart || '0').replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  return `${negative ? '-' : ''}${withCommas}${decPart !== undefined ? '.' + decPart : ''}`;
}
