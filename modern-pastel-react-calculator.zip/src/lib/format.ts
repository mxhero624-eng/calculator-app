/** Parse a controlled string input into a finite number (empty / invalid -> fallback). */
export function num(value: string, fallback = 0): number {
  if (value === undefined || value === null) return fallback;
  const cleaned = String(value).replace(/,/g, '').trim();
  if (cleaned === '' || cleaned === '-' || cleaned === '.') return fallback;
  const n = Number(cleaned);
  return Number.isFinite(n) ? n : fallback;
}

/** Remove floating point noise like 0.1 + 0.2 = 0.30000000000000004 */
export function clean(n: number, precision = 12): number {
  if (!Number.isFinite(n)) return n;
  return Number.parseFloat(n.toPrecision(precision));
}

/** Format a number with commas and a fixed number of decimals. */
export function fmt(n: number, decimals = 2): string {
  if (!Number.isFinite(n)) return '—';
  return n.toLocaleString('en-US', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  });
}

/** Format money with $ sign. */
export function money(n: number, decimals = 2): string {
  if (!Number.isFinite(n)) return '—';
  const sign = n < 0 ? '-' : '';
  return `${sign}$${fmt(Math.abs(n), decimals)}`;
}

/** Smart formatting for arbitrary magnitudes (unit conversions etc). */
export function smart(n: number, sig = 10): string {
  if (!Number.isFinite(n)) return '—';
  if (n === 0) return '0';
  const abs = Math.abs(n);
  if (abs >= 1e15 || abs < 1e-7) {
    return n.toExponential(4).replace(/\.?0+e/, 'e');
  }
  const c = Number.parseFloat(n.toPrecision(sig));
  return c.toLocaleString('en-US', { maximumFractionDigits: 10 });
}

/** Format integer with commas. */
export function int(n: number): string {
  if (!Number.isFinite(n)) return '—';
  return Math.round(n).toLocaleString('en-US');
}

export function plural(n: number, word: string): string {
  return `${n.toLocaleString('en-US')} ${word}${Math.abs(n) === 1 ? '' : 's'}`;
}
